import random

def detect_disaster(sensor_data):
    # Simulate ML-based decision using thresholds
    if sensor_data['temperature'] > 50 and sensor_data['smoke'] > 70:
        return "Forest Fire Alert"
    elif sensor_data['water_level'] > 80:
        return "Flood Alert"
    else:
        return "Safe"

# Simulated sensor data
data = {
    'temperature': random.randint(30, 60),
    'smoke': random.randint(20, 100),
    'water_level': random.randint(50, 100)
}

status = detect_disaster(data)
print("Disaster Status:", status)
